from django.shortcuts import render, redirect
from .models import Task
from .forms import TaskForm


def home(request):
    tasks = Task.objects.order_by('id')
    return render(request, 'main/home.html', {'title': 'Главная', 'tasks': tasks})


def base(request):
    return render(request, 'main/base.html')


def createm(request):
    error = ''
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
        else:
            error = 'Неверная форма'

    form = TaskForm()
    context = {
        'form': form,
        'error': error
    }
    return render(request, 'main/createm.html', context)

from django.shortcuts import render, redirect
from .models import Article
from .forms import ArticleForm
from django.views.generic import DetailView, UpdateView, DeleteView



def basa_v(request):
    basa = Article.objects.order_by('title')
    return render(request, 'basa/basa_v.html', {'basa': basa})


class BasaDetail(DetailView):
    model = Article
    template_name = 'basa/daba.html'
    context_object_name = 'article'


class BasaUpdate(UpdateView):
    model = Article
    template_name = 'basa/create.html'

    form_class = ArticleForm


class BasaDelete(DeleteView):
    model = Article
    success_url = '/basa'
    template_name = 'basa/basa_delete.html'


def create(request):
    error = ''
    if request.method == 'POST':
        form = ArticleForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('basa_v')
        else:
            error = 'Неверная форма'

    form = ArticleForm()

    data = {
        'form': form,
        'error': error
    }
    return render(request, 'basa/create.html', data)

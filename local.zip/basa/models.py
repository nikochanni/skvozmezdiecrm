from django.db import models


class Article(models.Model):
    title = models.CharField('Название', max_length=50)
    number = models.TextField('Номер')
    email = models.TextField('Email')
    full_text = models.TextField('Инфо')
    date = models.DateField('Дата')

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return f'/basa{self.id}'

    class Meta:
        verbose_name = 'Компания'
        verbose_name_plural = 'Компании'


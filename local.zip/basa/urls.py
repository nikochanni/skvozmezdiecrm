from django.urls import path
from . import views

urlpatterns = [
    path('', views.basa_v, name='basa_v'),
    path('create', views.create, name='create'),
    path('<int:pk>', views.BasaDetail.as_view(), name='basa-d'),
    path('<int:pk>/update', views.BasaUpdate.as_view(), name='basa-update'),
    path('<int:pk>/delete', views.BasaDelete.as_view(), name='basa-delete'),
]
